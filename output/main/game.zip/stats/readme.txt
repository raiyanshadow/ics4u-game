There will be a statistics file which collects the following data
every time the player DIES, exitting the game before dying does not record the data
The following data is gathered:
- Score Achieved
- Rounds Cleared
- Damage Dealt
- Damage Recieved
- HP Refilled
- Number of Each Enemy Type Killed
- Number of Times the Player Dashed
- Number of Times the Player Jumped
- Time Elapsed of Playing (pause time not included)